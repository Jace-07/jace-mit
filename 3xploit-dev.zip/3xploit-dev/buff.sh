echo "A";
while(echo < 1032); 
	do {

	echo;

	};
done
