# include <string.h>

void function (char *str) {
  char buffer[1024];
  
  strcpy(buffer,str);
}

int main (int argc, char *argv[])
{
  char aaa[500];
    function(argv[1]);
}
