#usr/bin/python3


def buff():
	print(A) * 1023

if '__name__' == "__main__":
	buff()
